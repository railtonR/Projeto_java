
package cadastrodeprodutos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;



public class CadastroDeProdutos extends JFrame {
    private Connection con;
    private Statement stmt;

    private JTextField nomeField, descricaoField, precoField, quantidadeField;
    private JComboBox<String> produtosComboBox;

    
    public CadastroDeProdutos() {
        super("Cadastro de Produtos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver encontrado!");

            String url = "jdbc:mysql://localhost:3306/produtosdb";
            String user = "root";
            String password = "";
            con = DriverManager.getConnection(url, user, password);
            stmt = con.createStatement();
            System.out.println("Conectado ao Banco de Dados");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erro: " + e.getMessage());
            return;
        }

        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel produtoLabel = new JLabel("Selecione o produto:");
        produtosComboBox = new JComboBox<>();
        carregarProdutos();
        panel.add(produtoLabel);
        panel.add(produtosComboBox);

        JLabel nameLabel = new JLabel("Nome:");
        nomeField = new JTextField();
        panel.add(nameLabel);
        panel.add(nomeField);

        JLabel descLabel = new JLabel("Descrição:");
        descricaoField = new JTextField();
        panel.add(descLabel);
        panel.add(descricaoField);

        JLabel precoLabel = new JLabel("Preço:");
        precoField = new JTextField();
        panel.add(precoLabel);
        panel.add(precoField);

        JLabel quantidadeLabel = new JLabel("Quantidade:");
        quantidadeField = new JTextField();
        panel.add(quantidadeLabel);
        panel.add(quantidadeField);

        JButton addButton = new JButton("Adicionar Produto");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarProduto();
            }
        });
        panel.add(addButton);

        JButton updateButton = new JButton("Atualizar Produto");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizarProduto();
            }
        });
        panel.add(updateButton);

        JButton deleteButton = new JButton("Excluir Produto");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirProduto();
            }
        });
        panel.add(deleteButton);

        JButton listButton = new JButton("Listar Produtos");
        listButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarProdutos();
            }
        });
        panel.add(listButton);

        getContentPane().add(panel);
    }

    private void carregarProdutos() {
        produtosComboBox.removeAllItems();
        try {
            ResultSet rs = stmt.executeQuery("SELECT nome FROM produtos");
            while (rs.next()) {
                String nome = rs.getString("nome");
                produtosComboBox.addItem(nome);
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println("Erro ao carregar produtos: " + e.getMessage());
        }
    }

    private void adicionarProduto() {
        String nome = nomeField.getText();
        String descricao = descricaoField.getText();
        String precoStr = precoField.getText().replace(",", ".");
        String quantidadeStr = quantidadeField.getText();

        try {
            double preco = Double.parseDouble(precoStr);
            int quantidade = Integer.parseInt(quantidadeStr);

            String sql = "INSERT INTO produtos (nome, descricao, preco, quantidade) VALUES ('" + nome + "', '" + descricao + "', " + preco + ", " + quantidade + ")";
            int rowsAffected = stmt.executeUpdate(sql);
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Produto adicionado com sucesso!");
                carregarProdutos(); // Atualiza a lista de produtos
            } else {
                JOptionPane.showMessageDialog(this, "Falha ao adicionar o produto.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Erro: Formato de número inválido. Use ponto como separador decimal.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao adicionar produto: " + e.getMessage());
        }
    }

    private void atualizarProduto() {
        String nomeSelecionado = (String) produtosComboBox.getSelectedItem();
        if (nomeSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Nenhum produto selecionado.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nome = nomeField.getText();
        String descricao = descricaoField.getText();
        String precoStr = precoField.getText().replace(",", ".");
        String quantidadeStr = quantidadeField.getText();

        try {
            double preco = Double.parseDouble(precoStr);
            int quantidade = Integer.parseInt(quantidadeStr);

            String sql = "UPDATE produtos SET nome = '" + nome + "', descricao = '" + descricao + "', preco = " + preco + ", quantidade = " + quantidade + " WHERE nome = '" + nomeSelecionado + "'";
            int rowsAffected = stmt.executeUpdate(sql);
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Produto atualizado com sucesso!");
                carregarProdutos(); // Atualiza a lista de produtos
            } else {
                JOptionPane.showMessageDialog(this, "Nenhum produto foi atualizado. Verifique o nome fornecido.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Erro: Formato de número inválido. Use ponto como separador decimal.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao atualizar produto: " + e.getMessage());
        }
    }

    private void excluirProduto() {
        String nomeSelecionado = (String) produtosComboBox.getSelectedItem();
        if (nomeSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Nenhum produto selecionado.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            String sql = "DELETE FROM produtos WHERE nome = '" + nomeSelecionado + "'";
            int rowsAffected = stmt.executeUpdate(sql);
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Produto excluído com sucesso!");
                carregarProdutos(); // Atualiza a lista de produtos
            } else {
                JOptionPane.showMessageDialog(this, "Nenhum produto foi excluído. Verifique o nome fornecido.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao excluir produto: " + e.getMessage());
        }
    }

    private void listarProdutos() {
        try {
            StringBuilder produtos = new StringBuilder();
            ResultSet rs = stmt.executeQuery("SELECT * FROM produtos");
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String descricao = rs.getString("descricao");
                double preco = rs.getDouble("preco");
                int quantidade = rs.getInt("quantidade");
                produtos.append("ID: ").append(id).append(", Nome: ").append(nome).append(", Descrição: ").append(descricao)
                        .append(", Preço: ").append(preco).append(", Quantidade: ").append(quantidade).append("\n");
            }
            rs.close();
            JOptionPane.showMessageDialog(this, produtos.toString(), "Lista de Produtos", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao listar produtos: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    
    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CadastroDeProdutos().setVisible(true);
            }
        });
    }
}

